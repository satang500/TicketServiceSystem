package com.walmart.ticketservice.model;

/**
 * Seat status enum
 * @author user
 *
 */
public enum SeatStatus {
    AVAILABLE,
    HOLD,
    RESERVED
}
